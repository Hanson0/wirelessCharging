Before using application software, please click into NI website www.ni.com - NI-VISA to download NI driver or NI-VISA Runtime. 
After setup Excel Addin software (enclosed in the CD), or your own programs, it will be controlled easily.

Run the self-extracting executable. This will install the NI-VISA 5.4 Run-Time engine.

Operating system: ETS; VxWorks; NI Linux RT; Windows 8 32-bit; Windows 8 64-bit; Windows 7 64-bit; Windows 7 32-bit; Windows Vista 64-bit; Windows Vista 32-bit; Windows XP (SP3) 32-bit; Windows Server 2008 R2 64-bit; Windows Server 2003 R2 32-bit