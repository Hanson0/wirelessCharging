﻿namespace wirelessCharging
{
    partial class Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Setting));
            this.check50mA = new DevExpress.XtraEditors.CheckEdit();
            this.check400mA = new DevExpress.XtraEditors.CheckEdit();
            this.check500mA = new DevExpress.XtraEditors.CheckEdit();
            this.check600mA = new DevExpress.XtraEditors.CheckEdit();
            this.check300mA = new DevExpress.XtraEditors.CheckEdit();
            this.check200mA = new DevExpress.XtraEditors.CheckEdit();
            this.check150mA = new DevExpress.XtraEditors.CheckEdit();
            this.check100mA = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.textI50mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.textI50mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI50mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.textI50mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI50mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.textI50mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI50mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.textI50mAFS = new DevExpress.XtraEditors.TextEdit();
            this.btnSure = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnClearText = new DevExpress.XtraEditors.SimpleButton();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.panelParam = new DevExpress.XtraEditors.PanelControl();
            this.panelParam100mA = new DevExpress.XtraEditors.PanelControl();
            this.textI100mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI100mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.textI100mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI100mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.textI100mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI100mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.textI100mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI100mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.panelParam150mA = new DevExpress.XtraEditors.PanelControl();
            this.textI150mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI150mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.textI150mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI150mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.textI150mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI150mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.textI150mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI150mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.panelParam200mA = new DevExpress.XtraEditors.PanelControl();
            this.textI200mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI200mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.textI200mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI200mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.textI200mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI200mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.textI200mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI200mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.panelParam300mA = new DevExpress.XtraEditors.PanelControl();
            this.textI300mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI300mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.textI300mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI300mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.textI300mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI300mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.textI300mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI300mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.panelParam400mA = new DevExpress.XtraEditors.PanelControl();
            this.textI400mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI400mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.textI400mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI400mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.textI400mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI400mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.textI400mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI400mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.panelParam500mA = new DevExpress.XtraEditors.PanelControl();
            this.textI500mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI500mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.textI500mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI500mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.textI500mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI500mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.textI500mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI500mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.panelParam600mA = new DevExpress.XtraEditors.PanelControl();
            this.textI600mAIS = new DevExpress.XtraEditors.TextEdit();
            this.textI600mAIE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.textI600mAVS = new DevExpress.XtraEditors.TextEdit();
            this.textI600mAVE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.textI600mAES = new DevExpress.XtraEditors.TextEdit();
            this.textI600mAEE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.textI600mAFS = new DevExpress.XtraEditors.TextEdit();
            this.textI600mAFE = new DevExpress.XtraEditors.TextEdit();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.panelI = new DevExpress.XtraEditors.PanelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.checkProName2 = new DevExpress.XtraEditors.CheckEdit();
            this.checkProName1 = new DevExpress.XtraEditors.CheckEdit();
            ((System.ComponentModel.ISupportInitialize)(this.check50mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check400mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check500mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check600mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check300mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check200mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check150mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check100mA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam)).BeginInit();
            this.panelParam.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam100mA)).BeginInit();
            this.panelParam100mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam150mA)).BeginInit();
            this.panelParam150mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam200mA)).BeginInit();
            this.panelParam200mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam300mA)).BeginInit();
            this.panelParam300mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam400mA)).BeginInit();
            this.panelParam400mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam500mA)).BeginInit();
            this.panelParam500mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam600mA)).BeginInit();
            this.panelParam600mA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAIS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAIE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAVS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAVE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAES.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAEE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAFS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAFE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelI)).BeginInit();
            this.panelI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkProName2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkProName1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // check50mA
            // 
            this.check50mA.Location = new System.Drawing.Point(14, 41);
            this.check50mA.Name = "check50mA";
            this.check50mA.Properties.Caption = "50mA";
            this.check50mA.Size = new System.Drawing.Size(69, 22);
            this.check50mA.TabIndex = 5;
            this.check50mA.CheckedChanged += new System.EventHandler(this.check50mA_CheckedChanged);
            // 
            // check400mA
            // 
            this.check400mA.Location = new System.Drawing.Point(14, 270);
            this.check400mA.Name = "check400mA";
            this.check400mA.Properties.Caption = "400mA";
            this.check400mA.Size = new System.Drawing.Size(69, 22);
            this.check400mA.TabIndex = 6;
            this.check400mA.CheckedChanged += new System.EventHandler(this.check400mA_CheckedChanged);
            // 
            // check500mA
            // 
            this.check500mA.Location = new System.Drawing.Point(14, 316);
            this.check500mA.Name = "check500mA";
            this.check500mA.Properties.Caption = "500mA";
            this.check500mA.Size = new System.Drawing.Size(69, 22);
            this.check500mA.TabIndex = 7;
            this.check500mA.CheckedChanged += new System.EventHandler(this.check500mA_CheckedChanged);
            // 
            // check600mA
            // 
            this.check600mA.Location = new System.Drawing.Point(14, 364);
            this.check600mA.Name = "check600mA";
            this.check600mA.Properties.Caption = "600mA";
            this.check600mA.Size = new System.Drawing.Size(69, 22);
            this.check600mA.TabIndex = 8;
            this.check600mA.CheckedChanged += new System.EventHandler(this.check600mA_CheckedChanged);
            // 
            // check300mA
            // 
            this.check300mA.Location = new System.Drawing.Point(13, 228);
            this.check300mA.Name = "check300mA";
            this.check300mA.Properties.Caption = "300mA";
            this.check300mA.Size = new System.Drawing.Size(69, 22);
            this.check300mA.TabIndex = 9;
            this.check300mA.CheckedChanged += new System.EventHandler(this.check300mA_CheckedChanged);
            // 
            // check200mA
            // 
            this.check200mA.Location = new System.Drawing.Point(13, 181);
            this.check200mA.Name = "check200mA";
            this.check200mA.Properties.Caption = "200mA";
            this.check200mA.Size = new System.Drawing.Size(69, 22);
            this.check200mA.TabIndex = 10;
            this.check200mA.CheckedChanged += new System.EventHandler(this.check200mA_CheckedChanged);
            // 
            // check150mA
            // 
            this.check150mA.Location = new System.Drawing.Point(14, 137);
            this.check150mA.Name = "check150mA";
            this.check150mA.Properties.Caption = "150mA";
            this.check150mA.Size = new System.Drawing.Size(69, 22);
            this.check150mA.TabIndex = 11;
            this.check150mA.CheckedChanged += new System.EventHandler(this.check150mA_CheckedChanged);
            // 
            // check100mA
            // 
            this.check100mA.Location = new System.Drawing.Point(14, 84);
            this.check100mA.Name = "check100mA";
            this.check100mA.Properties.Caption = "100mA";
            this.check100mA.Size = new System.Drawing.Size(69, 22);
            this.check100mA.TabIndex = 12;
            this.check100mA.CheckedChanged += new System.EventHandler(this.check100mA_CheckedChanged);
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(56, 14);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(91, 18);
            this.labelControl1.TabIndex = 13;
            this.labelControl1.Text = "WPC Iin（A）";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(245, 14);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(105, 18);
            this.labelControl2.TabIndex = 14;
            this.labelControl2.Text = "WPC Vout（V）";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(423, 14);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(56, 18);
            this.labelControl3.TabIndex = 15;
            this.labelControl3.Text = "WPC Eff";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(614, 14);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(102, 18);
            this.labelControl4.TabIndex = 16;
            this.labelControl4.Text = "WPC FREQ(HZ)";
            // 
            // textI50mAIE
            // 
            this.textI50mAIE.Location = new System.Drawing.Point(94, 39);
            this.textI50mAIE.Name = "textI50mAIE";
            this.textI50mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI50mAIE.TabIndex = 17;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(75, 39);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(13, 22);
            this.labelControl5.TabIndex = 18;
            this.labelControl5.Text = "~";
            // 
            // textI50mAIS
            // 
            this.textI50mAIS.Location = new System.Drawing.Point(12, 39);
            this.textI50mAIS.Name = "textI50mAIS";
            this.textI50mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI50mAIS.TabIndex = 19;
            // 
            // textI50mAVE
            // 
            this.textI50mAVE.Location = new System.Drawing.Point(286, 39);
            this.textI50mAVE.Name = "textI50mAVE";
            this.textI50mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI50mAVE.TabIndex = 22;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(269, 39);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(13, 22);
            this.labelControl6.TabIndex = 21;
            this.labelControl6.Text = "~";
            // 
            // textI50mAVS
            // 
            this.textI50mAVS.Location = new System.Drawing.Point(204, 38);
            this.textI50mAVS.Name = "textI50mAVS";
            this.textI50mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI50mAVS.TabIndex = 20;
            // 
            // textI50mAEE
            // 
            this.textI50mAEE.Location = new System.Drawing.Point(474, 39);
            this.textI50mAEE.Name = "textI50mAEE";
            this.textI50mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI50mAEE.TabIndex = 25;
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(457, 39);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(13, 22);
            this.labelControl7.TabIndex = 24;
            this.labelControl7.Text = "~";
            // 
            // textI50mAES
            // 
            this.textI50mAES.Location = new System.Drawing.Point(392, 39);
            this.textI50mAES.Name = "textI50mAES";
            this.textI50mAES.Size = new System.Drawing.Size(59, 24);
            this.textI50mAES.TabIndex = 23;
            // 
            // textI50mAFE
            // 
            this.textI50mAFE.Location = new System.Drawing.Point(659, 38);
            this.textI50mAFE.Name = "textI50mAFE";
            this.textI50mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI50mAFE.TabIndex = 28;
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(642, 39);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(13, 22);
            this.labelControl8.TabIndex = 27;
            this.labelControl8.Text = "~";
            // 
            // textI50mAFS
            // 
            this.textI50mAFS.Location = new System.Drawing.Point(577, 39);
            this.textI50mAFS.Name = "textI50mAFS";
            this.textI50mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI50mAFS.TabIndex = 26;
            // 
            // btnSure
            // 
            this.btnSure.Location = new System.Drawing.Point(526, 57);
            this.btnSure.Name = "btnSure";
            this.btnSure.Size = new System.Drawing.Size(87, 33);
            this.btnSure.TabIndex = 113;
            this.btnSure.Text = "锁定";
            this.btnSure.Click += new System.EventHandler(this.btnSure_Click);
            // 
            // panelControl1
            // 
            this.panelControl1.Location = new System.Drawing.Point(526, 12);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(71, 25);
            this.panelControl1.TabIndex = 114;
            // 
            // btnClearText
            // 
            this.btnClearText.Location = new System.Drawing.Point(733, 57);
            this.btnClearText.Name = "btnClearText";
            this.btnClearText.Size = new System.Drawing.Size(87, 33);
            this.btnClearText.TabIndex = 118;
            this.btnClearText.Text = "清除";
            this.btnClearText.Click += new System.EventHandler(this.btnClearText_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(632, 57);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(87, 33);
            this.btnCancel.TabIndex = 120;
            this.btnCancel.Text = "解锁";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panelParam
            // 
            this.panelParam.Controls.Add(this.labelControl1);
            this.panelParam.Controls.Add(this.textI50mAIS);
            this.panelParam.Controls.Add(this.textI50mAIE);
            this.panelParam.Controls.Add(this.labelControl5);
            this.panelParam.Controls.Add(this.labelControl2);
            this.panelParam.Controls.Add(this.textI50mAVS);
            this.panelParam.Controls.Add(this.textI50mAVE);
            this.panelParam.Controls.Add(this.labelControl6);
            this.panelParam.Controls.Add(this.labelControl3);
            this.panelParam.Controls.Add(this.textI50mAES);
            this.panelParam.Controls.Add(this.textI50mAEE);
            this.panelParam.Controls.Add(this.labelControl7);
            this.panelParam.Controls.Add(this.labelControl4);
            this.panelParam.Controls.Add(this.textI50mAFS);
            this.panelParam.Controls.Add(this.textI50mAFE);
            this.panelParam.Controls.Add(this.labelControl8);
            this.panelParam.Location = new System.Drawing.Point(134, 117);
            this.panelParam.Name = "panelParam";
            this.panelParam.Size = new System.Drawing.Size(808, 70);
            this.panelParam.TabIndex = 122;
            // 
            // panelParam100mA
            // 
            this.panelParam100mA.Controls.Add(this.textI100mAIS);
            this.panelParam100mA.Controls.Add(this.textI100mAIE);
            this.panelParam100mA.Controls.Add(this.labelControl38);
            this.panelParam100mA.Controls.Add(this.textI100mAVS);
            this.panelParam100mA.Controls.Add(this.textI100mAVE);
            this.panelParam100mA.Controls.Add(this.labelControl40);
            this.panelParam100mA.Controls.Add(this.textI100mAES);
            this.panelParam100mA.Controls.Add(this.textI100mAEE);
            this.panelParam100mA.Controls.Add(this.labelControl42);
            this.panelParam100mA.Controls.Add(this.textI100mAFS);
            this.panelParam100mA.Controls.Add(this.textI100mAFE);
            this.panelParam100mA.Controls.Add(this.labelControl44);
            this.panelParam100mA.Location = new System.Drawing.Point(134, 186);
            this.panelParam100mA.Name = "panelParam100mA";
            this.panelParam100mA.Size = new System.Drawing.Size(808, 47);
            this.panelParam100mA.TabIndex = 125;
            // 
            // textI100mAIS
            // 
            this.textI100mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI100mAIS.Name = "textI100mAIS";
            this.textI100mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI100mAIS.TabIndex = 19;
            // 
            // textI100mAIE
            // 
            this.textI100mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI100mAIE.Name = "textI100mAIE";
            this.textI100mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI100mAIE.TabIndex = 17;
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl38.Location = new System.Drawing.Point(75, 14);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(13, 22);
            this.labelControl38.TabIndex = 18;
            this.labelControl38.Text = "~";
            // 
            // textI100mAVS
            // 
            this.textI100mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI100mAVS.Name = "textI100mAVS";
            this.textI100mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI100mAVS.TabIndex = 20;
            // 
            // textI100mAVE
            // 
            this.textI100mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI100mAVE.Name = "textI100mAVE";
            this.textI100mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI100mAVE.TabIndex = 22;
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl40.Location = new System.Drawing.Point(269, 14);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(13, 22);
            this.labelControl40.TabIndex = 21;
            this.labelControl40.Text = "~";
            // 
            // textI100mAES
            // 
            this.textI100mAES.Location = new System.Drawing.Point(392, 14);
            this.textI100mAES.Name = "textI100mAES";
            this.textI100mAES.Size = new System.Drawing.Size(59, 24);
            this.textI100mAES.TabIndex = 23;
            // 
            // textI100mAEE
            // 
            this.textI100mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI100mAEE.Name = "textI100mAEE";
            this.textI100mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI100mAEE.TabIndex = 25;
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl42.Location = new System.Drawing.Point(457, 14);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(13, 22);
            this.labelControl42.TabIndex = 24;
            this.labelControl42.Text = "~";
            // 
            // textI100mAFS
            // 
            this.textI100mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI100mAFS.Name = "textI100mAFS";
            this.textI100mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI100mAFS.TabIndex = 26;
            // 
            // textI100mAFE
            // 
            this.textI100mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI100mAFE.Name = "textI100mAFE";
            this.textI100mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI100mAFE.TabIndex = 28;
            // 
            // labelControl44
            // 
            this.labelControl44.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl44.Location = new System.Drawing.Point(642, 14);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(13, 22);
            this.labelControl44.TabIndex = 27;
            this.labelControl44.Text = "~";
            // 
            // panelParam150mA
            // 
            this.panelParam150mA.Controls.Add(this.textI150mAIS);
            this.panelParam150mA.Controls.Add(this.textI150mAIE);
            this.panelParam150mA.Controls.Add(this.labelControl9);
            this.panelParam150mA.Controls.Add(this.textI150mAVS);
            this.panelParam150mA.Controls.Add(this.textI150mAVE);
            this.panelParam150mA.Controls.Add(this.labelControl10);
            this.panelParam150mA.Controls.Add(this.textI150mAES);
            this.panelParam150mA.Controls.Add(this.textI150mAEE);
            this.panelParam150mA.Controls.Add(this.labelControl11);
            this.panelParam150mA.Controls.Add(this.textI150mAFS);
            this.panelParam150mA.Controls.Add(this.textI150mAFE);
            this.panelParam150mA.Controls.Add(this.labelControl12);
            this.panelParam150mA.Location = new System.Drawing.Point(134, 239);
            this.panelParam150mA.Name = "panelParam150mA";
            this.panelParam150mA.Size = new System.Drawing.Size(808, 47);
            this.panelParam150mA.TabIndex = 126;
            // 
            // textI150mAIS
            // 
            this.textI150mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI150mAIS.Name = "textI150mAIS";
            this.textI150mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI150mAIS.TabIndex = 19;
            // 
            // textI150mAIE
            // 
            this.textI150mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI150mAIE.Name = "textI150mAIE";
            this.textI150mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI150mAIE.TabIndex = 17;
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(75, 14);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(13, 22);
            this.labelControl9.TabIndex = 18;
            this.labelControl9.Text = "~";
            // 
            // textI150mAVS
            // 
            this.textI150mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI150mAVS.Name = "textI150mAVS";
            this.textI150mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI150mAVS.TabIndex = 20;
            // 
            // textI150mAVE
            // 
            this.textI150mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI150mAVE.Name = "textI150mAVE";
            this.textI150mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI150mAVE.TabIndex = 22;
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(269, 14);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(13, 22);
            this.labelControl10.TabIndex = 21;
            this.labelControl10.Text = "~";
            // 
            // textI150mAES
            // 
            this.textI150mAES.Location = new System.Drawing.Point(392, 14);
            this.textI150mAES.Name = "textI150mAES";
            this.textI150mAES.Size = new System.Drawing.Size(59, 24);
            this.textI150mAES.TabIndex = 23;
            // 
            // textI150mAEE
            // 
            this.textI150mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI150mAEE.Name = "textI150mAEE";
            this.textI150mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI150mAEE.TabIndex = 25;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(457, 14);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(13, 22);
            this.labelControl11.TabIndex = 24;
            this.labelControl11.Text = "~";
            // 
            // textI150mAFS
            // 
            this.textI150mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI150mAFS.Name = "textI150mAFS";
            this.textI150mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI150mAFS.TabIndex = 26;
            // 
            // textI150mAFE
            // 
            this.textI150mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI150mAFE.Name = "textI150mAFE";
            this.textI150mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI150mAFE.TabIndex = 28;
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(642, 14);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(13, 22);
            this.labelControl12.TabIndex = 27;
            this.labelControl12.Text = "~";
            // 
            // panelParam200mA
            // 
            this.panelParam200mA.Controls.Add(this.textI200mAIS);
            this.panelParam200mA.Controls.Add(this.textI200mAIE);
            this.panelParam200mA.Controls.Add(this.labelControl13);
            this.panelParam200mA.Controls.Add(this.textI200mAVS);
            this.panelParam200mA.Controls.Add(this.textI200mAVE);
            this.panelParam200mA.Controls.Add(this.labelControl14);
            this.panelParam200mA.Controls.Add(this.textI200mAES);
            this.panelParam200mA.Controls.Add(this.textI200mAEE);
            this.panelParam200mA.Controls.Add(this.labelControl15);
            this.panelParam200mA.Controls.Add(this.textI200mAFS);
            this.panelParam200mA.Controls.Add(this.textI200mAFE);
            this.panelParam200mA.Controls.Add(this.labelControl16);
            this.panelParam200mA.Location = new System.Drawing.Point(134, 283);
            this.panelParam200mA.Name = "panelParam200mA";
            this.panelParam200mA.Size = new System.Drawing.Size(808, 47);
            this.panelParam200mA.TabIndex = 127;
            // 
            // textI200mAIS
            // 
            this.textI200mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI200mAIS.Name = "textI200mAIS";
            this.textI200mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI200mAIS.TabIndex = 19;
            // 
            // textI200mAIE
            // 
            this.textI200mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI200mAIE.Name = "textI200mAIE";
            this.textI200mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI200mAIE.TabIndex = 17;
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(75, 14);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(13, 22);
            this.labelControl13.TabIndex = 18;
            this.labelControl13.Text = "~";
            // 
            // textI200mAVS
            // 
            this.textI200mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI200mAVS.Name = "textI200mAVS";
            this.textI200mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI200mAVS.TabIndex = 20;
            // 
            // textI200mAVE
            // 
            this.textI200mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI200mAVE.Name = "textI200mAVE";
            this.textI200mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI200mAVE.TabIndex = 22;
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(269, 14);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(13, 22);
            this.labelControl14.TabIndex = 21;
            this.labelControl14.Text = "~";
            // 
            // textI200mAES
            // 
            this.textI200mAES.Location = new System.Drawing.Point(392, 14);
            this.textI200mAES.Name = "textI200mAES";
            this.textI200mAES.Size = new System.Drawing.Size(59, 24);
            this.textI200mAES.TabIndex = 23;
            // 
            // textI200mAEE
            // 
            this.textI200mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI200mAEE.Name = "textI200mAEE";
            this.textI200mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI200mAEE.TabIndex = 25;
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl15.Location = new System.Drawing.Point(457, 14);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(13, 22);
            this.labelControl15.TabIndex = 24;
            this.labelControl15.Text = "~";
            // 
            // textI200mAFS
            // 
            this.textI200mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI200mAFS.Name = "textI200mAFS";
            this.textI200mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI200mAFS.TabIndex = 26;
            // 
            // textI200mAFE
            // 
            this.textI200mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI200mAFE.Name = "textI200mAFE";
            this.textI200mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI200mAFE.TabIndex = 28;
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Location = new System.Drawing.Point(642, 14);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(13, 22);
            this.labelControl16.TabIndex = 27;
            this.labelControl16.Text = "~";
            // 
            // panelParam300mA
            // 
            this.panelParam300mA.Controls.Add(this.textI300mAIS);
            this.panelParam300mA.Controls.Add(this.textI300mAIE);
            this.panelParam300mA.Controls.Add(this.labelControl17);
            this.panelParam300mA.Controls.Add(this.textI300mAVS);
            this.panelParam300mA.Controls.Add(this.textI300mAVE);
            this.panelParam300mA.Controls.Add(this.labelControl18);
            this.panelParam300mA.Controls.Add(this.textI300mAES);
            this.panelParam300mA.Controls.Add(this.textI300mAEE);
            this.panelParam300mA.Controls.Add(this.labelControl19);
            this.panelParam300mA.Controls.Add(this.textI300mAFS);
            this.panelParam300mA.Controls.Add(this.textI300mAFE);
            this.panelParam300mA.Controls.Add(this.labelControl20);
            this.panelParam300mA.Location = new System.Drawing.Point(134, 330);
            this.panelParam300mA.Name = "panelParam300mA";
            this.panelParam300mA.Size = new System.Drawing.Size(808, 44);
            this.panelParam300mA.TabIndex = 128;
            // 
            // textI300mAIS
            // 
            this.textI300mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI300mAIS.Name = "textI300mAIS";
            this.textI300mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI300mAIS.TabIndex = 19;
            // 
            // textI300mAIE
            // 
            this.textI300mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI300mAIE.Name = "textI300mAIE";
            this.textI300mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI300mAIE.TabIndex = 17;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl17.Location = new System.Drawing.Point(75, 14);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(13, 22);
            this.labelControl17.TabIndex = 18;
            this.labelControl17.Text = "~";
            // 
            // textI300mAVS
            // 
            this.textI300mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI300mAVS.Name = "textI300mAVS";
            this.textI300mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI300mAVS.TabIndex = 20;
            // 
            // textI300mAVE
            // 
            this.textI300mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI300mAVE.Name = "textI300mAVE";
            this.textI300mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI300mAVE.TabIndex = 22;
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl18.Location = new System.Drawing.Point(269, 14);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(13, 22);
            this.labelControl18.TabIndex = 21;
            this.labelControl18.Text = "~";
            // 
            // textI300mAES
            // 
            this.textI300mAES.Location = new System.Drawing.Point(392, 14);
            this.textI300mAES.Name = "textI300mAES";
            this.textI300mAES.Size = new System.Drawing.Size(59, 24);
            this.textI300mAES.TabIndex = 23;
            // 
            // textI300mAEE
            // 
            this.textI300mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI300mAEE.Name = "textI300mAEE";
            this.textI300mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI300mAEE.TabIndex = 25;
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl19.Location = new System.Drawing.Point(457, 14);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(13, 22);
            this.labelControl19.TabIndex = 24;
            this.labelControl19.Text = "~";
            // 
            // textI300mAFS
            // 
            this.textI300mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI300mAFS.Name = "textI300mAFS";
            this.textI300mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI300mAFS.TabIndex = 26;
            // 
            // textI300mAFE
            // 
            this.textI300mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI300mAFE.Name = "textI300mAFE";
            this.textI300mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI300mAFE.TabIndex = 28;
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl20.Location = new System.Drawing.Point(642, 14);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(13, 22);
            this.labelControl20.TabIndex = 27;
            this.labelControl20.Text = "~";
            // 
            // panelParam400mA
            // 
            this.panelParam400mA.Controls.Add(this.textI400mAIS);
            this.panelParam400mA.Controls.Add(this.textI400mAIE);
            this.panelParam400mA.Controls.Add(this.labelControl21);
            this.panelParam400mA.Controls.Add(this.textI400mAVS);
            this.panelParam400mA.Controls.Add(this.textI400mAVE);
            this.panelParam400mA.Controls.Add(this.labelControl22);
            this.panelParam400mA.Controls.Add(this.textI400mAES);
            this.panelParam400mA.Controls.Add(this.textI400mAEE);
            this.panelParam400mA.Controls.Add(this.labelControl23);
            this.panelParam400mA.Controls.Add(this.textI400mAFS);
            this.panelParam400mA.Controls.Add(this.textI400mAFE);
            this.panelParam400mA.Controls.Add(this.labelControl24);
            this.panelParam400mA.Location = new System.Drawing.Point(134, 372);
            this.panelParam400mA.Name = "panelParam400mA";
            this.panelParam400mA.Size = new System.Drawing.Size(808, 44);
            this.panelParam400mA.TabIndex = 129;
            // 
            // textI400mAIS
            // 
            this.textI400mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI400mAIS.Name = "textI400mAIS";
            this.textI400mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI400mAIS.TabIndex = 19;
            // 
            // textI400mAIE
            // 
            this.textI400mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI400mAIE.Name = "textI400mAIE";
            this.textI400mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI400mAIE.TabIndex = 17;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl21.Location = new System.Drawing.Point(75, 14);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(13, 22);
            this.labelControl21.TabIndex = 18;
            this.labelControl21.Text = "~";
            // 
            // textI400mAVS
            // 
            this.textI400mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI400mAVS.Name = "textI400mAVS";
            this.textI400mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI400mAVS.TabIndex = 20;
            // 
            // textI400mAVE
            // 
            this.textI400mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI400mAVE.Name = "textI400mAVE";
            this.textI400mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI400mAVE.TabIndex = 22;
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl22.Location = new System.Drawing.Point(269, 14);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(13, 22);
            this.labelControl22.TabIndex = 21;
            this.labelControl22.Text = "~";
            // 
            // textI400mAES
            // 
            this.textI400mAES.Location = new System.Drawing.Point(392, 14);
            this.textI400mAES.Name = "textI400mAES";
            this.textI400mAES.Size = new System.Drawing.Size(59, 24);
            this.textI400mAES.TabIndex = 23;
            // 
            // textI400mAEE
            // 
            this.textI400mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI400mAEE.Name = "textI400mAEE";
            this.textI400mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI400mAEE.TabIndex = 25;
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl23.Location = new System.Drawing.Point(457, 14);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(13, 22);
            this.labelControl23.TabIndex = 24;
            this.labelControl23.Text = "~";
            // 
            // textI400mAFS
            // 
            this.textI400mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI400mAFS.Name = "textI400mAFS";
            this.textI400mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI400mAFS.TabIndex = 26;
            // 
            // textI400mAFE
            // 
            this.textI400mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI400mAFE.Name = "textI400mAFE";
            this.textI400mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI400mAFE.TabIndex = 28;
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl24.Location = new System.Drawing.Point(642, 14);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(13, 22);
            this.labelControl24.TabIndex = 27;
            this.labelControl24.Text = "~";
            // 
            // panelParam500mA
            // 
            this.panelParam500mA.Controls.Add(this.textI500mAIS);
            this.panelParam500mA.Controls.Add(this.textI500mAIE);
            this.panelParam500mA.Controls.Add(this.labelControl25);
            this.panelParam500mA.Controls.Add(this.textI500mAVS);
            this.panelParam500mA.Controls.Add(this.textI500mAVE);
            this.panelParam500mA.Controls.Add(this.labelControl26);
            this.panelParam500mA.Controls.Add(this.textI500mAES);
            this.panelParam500mA.Controls.Add(this.textI500mAEE);
            this.panelParam500mA.Controls.Add(this.labelControl27);
            this.panelParam500mA.Controls.Add(this.textI500mAFS);
            this.panelParam500mA.Controls.Add(this.textI500mAFE);
            this.panelParam500mA.Controls.Add(this.labelControl28);
            this.panelParam500mA.Location = new System.Drawing.Point(134, 416);
            this.panelParam500mA.Name = "panelParam500mA";
            this.panelParam500mA.Size = new System.Drawing.Size(808, 44);
            this.panelParam500mA.TabIndex = 130;
            // 
            // textI500mAIS
            // 
            this.textI500mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI500mAIS.Name = "textI500mAIS";
            this.textI500mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI500mAIS.TabIndex = 19;
            // 
            // textI500mAIE
            // 
            this.textI500mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI500mAIE.Name = "textI500mAIE";
            this.textI500mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI500mAIE.TabIndex = 17;
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl25.Location = new System.Drawing.Point(75, 14);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(13, 22);
            this.labelControl25.TabIndex = 18;
            this.labelControl25.Text = "~";
            // 
            // textI500mAVS
            // 
            this.textI500mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI500mAVS.Name = "textI500mAVS";
            this.textI500mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI500mAVS.TabIndex = 20;
            // 
            // textI500mAVE
            // 
            this.textI500mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI500mAVE.Name = "textI500mAVE";
            this.textI500mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI500mAVE.TabIndex = 22;
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl26.Location = new System.Drawing.Point(269, 14);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(13, 22);
            this.labelControl26.TabIndex = 21;
            this.labelControl26.Text = "~";
            // 
            // textI500mAES
            // 
            this.textI500mAES.Location = new System.Drawing.Point(392, 14);
            this.textI500mAES.Name = "textI500mAES";
            this.textI500mAES.Size = new System.Drawing.Size(59, 24);
            this.textI500mAES.TabIndex = 23;
            // 
            // textI500mAEE
            // 
            this.textI500mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI500mAEE.Name = "textI500mAEE";
            this.textI500mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI500mAEE.TabIndex = 25;
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl27.Location = new System.Drawing.Point(457, 14);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(13, 22);
            this.labelControl27.TabIndex = 24;
            this.labelControl27.Text = "~";
            // 
            // textI500mAFS
            // 
            this.textI500mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI500mAFS.Name = "textI500mAFS";
            this.textI500mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI500mAFS.TabIndex = 26;
            // 
            // textI500mAFE
            // 
            this.textI500mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI500mAFE.Name = "textI500mAFE";
            this.textI500mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI500mAFE.TabIndex = 28;
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl28.Location = new System.Drawing.Point(642, 14);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(13, 22);
            this.labelControl28.TabIndex = 27;
            this.labelControl28.Text = "~";
            // 
            // panelParam600mA
            // 
            this.panelParam600mA.Controls.Add(this.textI600mAIS);
            this.panelParam600mA.Controls.Add(this.textI600mAIE);
            this.panelParam600mA.Controls.Add(this.labelControl29);
            this.panelParam600mA.Controls.Add(this.textI600mAVS);
            this.panelParam600mA.Controls.Add(this.textI600mAVE);
            this.panelParam600mA.Controls.Add(this.labelControl30);
            this.panelParam600mA.Controls.Add(this.textI600mAES);
            this.panelParam600mA.Controls.Add(this.textI600mAEE);
            this.panelParam600mA.Controls.Add(this.labelControl31);
            this.panelParam600mA.Controls.Add(this.textI600mAFS);
            this.panelParam600mA.Controls.Add(this.textI600mAFE);
            this.panelParam600mA.Controls.Add(this.labelControl32);
            this.panelParam600mA.Location = new System.Drawing.Point(134, 466);
            this.panelParam600mA.Name = "panelParam600mA";
            this.panelParam600mA.Size = new System.Drawing.Size(808, 59);
            this.panelParam600mA.TabIndex = 131;
            // 
            // textI600mAIS
            // 
            this.textI600mAIS.Location = new System.Drawing.Point(12, 14);
            this.textI600mAIS.Name = "textI600mAIS";
            this.textI600mAIS.Size = new System.Drawing.Size(59, 24);
            this.textI600mAIS.TabIndex = 19;
            // 
            // textI600mAIE
            // 
            this.textI600mAIE.Location = new System.Drawing.Point(94, 14);
            this.textI600mAIE.Name = "textI600mAIE";
            this.textI600mAIE.Size = new System.Drawing.Size(59, 24);
            this.textI600mAIE.TabIndex = 17;
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl29.Location = new System.Drawing.Point(75, 14);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(13, 22);
            this.labelControl29.TabIndex = 18;
            this.labelControl29.Text = "~";
            // 
            // textI600mAVS
            // 
            this.textI600mAVS.Location = new System.Drawing.Point(204, 13);
            this.textI600mAVS.Name = "textI600mAVS";
            this.textI600mAVS.Size = new System.Drawing.Size(59, 24);
            this.textI600mAVS.TabIndex = 20;
            // 
            // textI600mAVE
            // 
            this.textI600mAVE.Location = new System.Drawing.Point(286, 14);
            this.textI600mAVE.Name = "textI600mAVE";
            this.textI600mAVE.Size = new System.Drawing.Size(59, 24);
            this.textI600mAVE.TabIndex = 22;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl30.Location = new System.Drawing.Point(269, 14);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(13, 22);
            this.labelControl30.TabIndex = 21;
            this.labelControl30.Text = "~";
            // 
            // textI600mAES
            // 
            this.textI600mAES.Location = new System.Drawing.Point(392, 14);
            this.textI600mAES.Name = "textI600mAES";
            this.textI600mAES.Size = new System.Drawing.Size(59, 24);
            this.textI600mAES.TabIndex = 23;
            // 
            // textI600mAEE
            // 
            this.textI600mAEE.Location = new System.Drawing.Point(474, 14);
            this.textI600mAEE.Name = "textI600mAEE";
            this.textI600mAEE.Size = new System.Drawing.Size(59, 24);
            this.textI600mAEE.TabIndex = 25;
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl31.Location = new System.Drawing.Point(457, 14);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(13, 22);
            this.labelControl31.TabIndex = 24;
            this.labelControl31.Text = "~";
            // 
            // textI600mAFS
            // 
            this.textI600mAFS.Location = new System.Drawing.Point(577, 14);
            this.textI600mAFS.Name = "textI600mAFS";
            this.textI600mAFS.Size = new System.Drawing.Size(59, 24);
            this.textI600mAFS.TabIndex = 26;
            // 
            // textI600mAFE
            // 
            this.textI600mAFE.Location = new System.Drawing.Point(659, 13);
            this.textI600mAFE.Name = "textI600mAFE";
            this.textI600mAFE.Size = new System.Drawing.Size(59, 24);
            this.textI600mAFE.TabIndex = 28;
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl32.Location = new System.Drawing.Point(642, 14);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(13, 22);
            this.labelControl32.TabIndex = 27;
            this.labelControl32.Text = "~";
            // 
            // panelI
            // 
            this.panelI.Controls.Add(this.check50mA);
            this.panelI.Controls.Add(this.check100mA);
            this.panelI.Controls.Add(this.check150mA);
            this.panelI.Controls.Add(this.check200mA);
            this.panelI.Controls.Add(this.check300mA);
            this.panelI.Controls.Add(this.check400mA);
            this.panelI.Controls.Add(this.check500mA);
            this.panelI.Controls.Add(this.check600mA);
            this.panelI.Location = new System.Drawing.Point(46, 116);
            this.panelI.Name = "panelI";
            this.panelI.Size = new System.Drawing.Size(88, 409);
            this.panelI.TabIndex = 119;
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.CaptionImage = ((System.Drawing.Image)(resources.GetObject("groupControl1.CaptionImage")));
            this.groupControl1.Controls.Add(this.checkProName2);
            this.groupControl1.Controls.Add(this.checkProName1);
            this.groupControl1.Location = new System.Drawing.Point(12, 2);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(467, 93);
            this.groupControl1.TabIndex = 117;
            this.groupControl1.Text = "产品型号";
            // 
            // checkProName2
            // 
            this.checkProName2.Location = new System.Drawing.Point(252, 53);
            this.checkProName2.Name = "checkProName2";
            this.checkProName2.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkProName2.Properties.Appearance.Options.UseFont = true;
            this.checkProName2.Properties.Caption = "WPC VG20";
            this.checkProName2.Properties.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Radio;
            this.checkProName2.Properties.RadioGroupIndex = 1;
            this.checkProName2.Size = new System.Drawing.Size(210, 26);
            this.checkProName2.TabIndex = 4;
            this.checkProName2.TabStop = false;
            this.checkProName2.CheckedChanged += new System.EventHandler(this.checkProName2_CheckedChanged);
            // 
            // checkProName1
            // 
            this.checkProName1.Location = new System.Drawing.Point(21, 53);
            this.checkProName1.Name = "checkProName1";
            this.checkProName1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkProName1.Properties.Appearance.Options.UseFont = true;
            this.checkProName1.Properties.Caption = "WPC VT65";
            this.checkProName1.Properties.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Radio;
            this.checkProName1.Properties.RadioGroupIndex = 1;
            this.checkProName1.Size = new System.Drawing.Size(225, 26);
            this.checkProName1.TabIndex = 3;
            this.checkProName1.TabStop = false;
            this.checkProName1.CheckedChanged += new System.EventHandler(this.checkProName1_CheckedChanged);
            // 
            // Setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1129, 951);
            this.Controls.Add(this.panelParam600mA);
            this.Controls.Add(this.panelParam500mA);
            this.Controls.Add(this.panelParam400mA);
            this.Controls.Add(this.panelParam300mA);
            this.Controls.Add(this.panelParam200mA);
            this.Controls.Add(this.panelParam150mA);
            this.Controls.Add(this.panelParam100mA);
            this.Controls.Add(this.panelParam);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.panelI);
            this.Controls.Add(this.btnClearText);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.btnSure);
            this.Name = "Setting";
            this.Text = "Setting";
            ((System.ComponentModel.ISupportInitialize)(this.check50mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check400mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check500mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check600mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check300mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check200mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check150mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check100mA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI50mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam)).EndInit();
            this.panelParam.ResumeLayout(false);
            this.panelParam.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam100mA)).EndInit();
            this.panelParam100mA.ResumeLayout(false);
            this.panelParam100mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI100mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam150mA)).EndInit();
            this.panelParam150mA.ResumeLayout(false);
            this.panelParam150mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI150mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam200mA)).EndInit();
            this.panelParam200mA.ResumeLayout(false);
            this.panelParam200mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI200mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam300mA)).EndInit();
            this.panelParam300mA.ResumeLayout(false);
            this.panelParam300mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI300mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam400mA)).EndInit();
            this.panelParam400mA.ResumeLayout(false);
            this.panelParam400mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI400mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam500mA)).EndInit();
            this.panelParam500mA.ResumeLayout(false);
            this.panelParam500mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI500mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelParam600mA)).EndInit();
            this.panelParam600mA.ResumeLayout(false);
            this.panelParam600mA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAIS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAIE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAVS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAVE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAES.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAEE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAFS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textI600mAFE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelI)).EndInit();
            this.panelI.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.checkProName2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkProName1.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.CheckEdit checkProName1;
        private DevExpress.XtraEditors.CheckEdit checkProName2;
        private DevExpress.XtraEditors.CheckEdit check50mA;
        private DevExpress.XtraEditors.CheckEdit check400mA;
        private DevExpress.XtraEditors.CheckEdit check500mA;
        private DevExpress.XtraEditors.CheckEdit check600mA;
        private DevExpress.XtraEditors.CheckEdit check300mA;
        private DevExpress.XtraEditors.CheckEdit check200mA;
        private DevExpress.XtraEditors.CheckEdit check150mA;
        private DevExpress.XtraEditors.CheckEdit check100mA;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit textI50mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit textI50mAIS;
        private DevExpress.XtraEditors.TextEdit textI50mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit textI50mAVS;
        private DevExpress.XtraEditors.TextEdit textI50mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit textI50mAES;
        private DevExpress.XtraEditors.TextEdit textI50mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit textI50mAFS;
        private DevExpress.XtraEditors.SimpleButton btnSure;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnClearText;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.PanelControl panelParam;
        private DevExpress.XtraEditors.PanelControl panelParam100mA;
        private DevExpress.XtraEditors.TextEdit textI100mAIS;
        private DevExpress.XtraEditors.TextEdit textI100mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.TextEdit textI100mAVS;
        private DevExpress.XtraEditors.TextEdit textI100mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.TextEdit textI100mAES;
        private DevExpress.XtraEditors.TextEdit textI100mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.TextEdit textI100mAFS;
        private DevExpress.XtraEditors.TextEdit textI100mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.PanelControl panelParam150mA;
        private DevExpress.XtraEditors.TextEdit textI150mAIS;
        private DevExpress.XtraEditors.TextEdit textI150mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit textI150mAVS;
        private DevExpress.XtraEditors.TextEdit textI150mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit textI150mAES;
        private DevExpress.XtraEditors.TextEdit textI150mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit textI150mAFS;
        private DevExpress.XtraEditors.TextEdit textI150mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.PanelControl panelParam200mA;
        private DevExpress.XtraEditors.TextEdit textI200mAIS;
        private DevExpress.XtraEditors.TextEdit textI200mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit textI200mAVS;
        private DevExpress.XtraEditors.TextEdit textI200mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit textI200mAES;
        private DevExpress.XtraEditors.TextEdit textI200mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.TextEdit textI200mAFS;
        private DevExpress.XtraEditors.TextEdit textI200mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.PanelControl panelParam300mA;
        private DevExpress.XtraEditors.TextEdit textI300mAIS;
        private DevExpress.XtraEditors.TextEdit textI300mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit textI300mAVS;
        private DevExpress.XtraEditors.TextEdit textI300mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit textI300mAES;
        private DevExpress.XtraEditors.TextEdit textI300mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.TextEdit textI300mAFS;
        private DevExpress.XtraEditors.TextEdit textI300mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.PanelControl panelParam400mA;
        private DevExpress.XtraEditors.TextEdit textI400mAIS;
        private DevExpress.XtraEditors.TextEdit textI400mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.TextEdit textI400mAVS;
        private DevExpress.XtraEditors.TextEdit textI400mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.TextEdit textI400mAES;
        private DevExpress.XtraEditors.TextEdit textI400mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.TextEdit textI400mAFS;
        private DevExpress.XtraEditors.TextEdit textI400mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.PanelControl panelParam500mA;
        private DevExpress.XtraEditors.TextEdit textI500mAIS;
        private DevExpress.XtraEditors.TextEdit textI500mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.TextEdit textI500mAVS;
        private DevExpress.XtraEditors.TextEdit textI500mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit textI500mAES;
        private DevExpress.XtraEditors.TextEdit textI500mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.TextEdit textI500mAFS;
        private DevExpress.XtraEditors.TextEdit textI500mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.PanelControl panelParam600mA;
        private DevExpress.XtraEditors.TextEdit textI600mAIS;
        private DevExpress.XtraEditors.TextEdit textI600mAIE;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.TextEdit textI600mAVS;
        private DevExpress.XtraEditors.TextEdit textI600mAVE;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.TextEdit textI600mAES;
        private DevExpress.XtraEditors.TextEdit textI600mAEE;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.TextEdit textI600mAFS;
        private DevExpress.XtraEditors.TextEdit textI600mAFE;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.PanelControl panelI;
    }
}