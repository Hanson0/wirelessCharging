﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using JiaHao.DX.FormBuild;
using DevExpress.XtraEditors;
namespace wirelessCharging
{
    public partial class MainForm : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        CreateForm creatForm = new CreateForm();
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnTest_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                string testFormName = typeof(WpcTest).ToString();
                creatForm.AddTabpage(xtraTabControl1, "TabPageTest", "性能测试", testFormName);
            }
            catch (Exception ex)
            {

                XtraMessageBox.Show(ex.Message);
            }
        }

        private void xtraTabControl1_CloseButtonClick(object sender, EventArgs e)
        {
            creatForm.RemoveTabPage(xtraTabControl1, e);
        }

        private void btnPack_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
             try
            {
                string InboxFormName = typeof(InBox).ToString();
                creatForm.AddTabpage(xtraTabControl1, "TabPageInBox", "装箱检查", InboxFormName);
            }
            catch (Exception ex)
            {

                XtraMessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
             try
            {
                string SearchFormName = typeof(Search).ToString();
                creatForm.AddTabpage(xtraTabControl1, "TabPageSearch", "Log查询", SearchFormName);
            }
            catch (Exception ex)
            {

                XtraMessageBox.Show(ex.Message);
            }            
        }

        private void btnSet_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            
             try
            {
                string SettingFormName = typeof(Setting).ToString();
                creatForm.AddTabpage(xtraTabControl1, "TabPageSetting", "参数设置", SettingFormName);
            }
            catch (Exception ex)
            {

                XtraMessageBox.Show(ex.Message);
            }            
        }
    }
}
